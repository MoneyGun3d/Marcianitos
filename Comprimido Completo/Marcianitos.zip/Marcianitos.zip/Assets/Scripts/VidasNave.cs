using Unity.VisualScripting;
using UnityEngine;

public class VidasNave : MonoBehaviour
{
    public static int vida = 3;

    void Start()
    {
        
    }

    public static void PerderVida(GameObject nave, int damage)
    {

    }
}


